# CW AI Agent (Carrd + Cloudflare Worker + Google Sheets)

This repo contains the backend code and setup notes for **Chris’ Assistant** — a lightweight AI-style lead capture agent that replaces ManyChat and runs on:

- **Cloudflare Workers** (serverless backend + session state)
- **Google Sheets** (CRM-style storage for contacts, leads, and events)
- **Carrd** (landing page embed via your chat widget calling the Worker `/chat` endpoint)

---

## Why we built this

ManyChat is powerful, but:
- Workflows can be hard to export/version
- Logic lives inside a proprietary UI
- Costs increase with contacts and usage
- Reproducing or migrating flows can be painful

This agent gives you:
- **Full ownership of the conversation logic**
- **Version control** (GitHub)
- **Portable backend** (Cloudflare Worker)
- **Simple CRM storage** (Google Sheets)

---

## What the bot does

### Main Menu (Quick Replies)
Users always see 3 options:

1. **House selling options**
2. **Find a home**
3. **Private Lending**

Typing **menu / restart / start over** returns the user to the main menu.

---

## Seller Flow (House selling options)

Questions asked:

1. Property address  
2. ZIP code (validated)  
3. Why selling  
4. Estimated value (rough guess ok)  
5. Condition: Fixed up / As-is / Not sure  
6. Sell timeframe: Within 3 months / 3–6 months / 12+ months  
7. First name  
8. Phone number  

After phone, user gets a confirmation + Calendly link:
`https://calendly.com/chriswhitwood`

Data logged:
- `Contacts` upsert
- `Leads` row appended (`intent = seller`)

---

## Buyer Flow (Find a home)

Questions asked:

1. Buy timeframe  
2. Price range  
3. Property type (Detached / Townhouse / Condo)  
4. Zip codes (comma separated)  
5. Funding type: Bank / Cash / Owner Financing  
6. If Bank → bank status: “I’m pre-approved” or “I need your lender”  
7. If Owner Financing → down payment + monthly cap  
8. First name  
9. Phone number  
10. Email (asked last)

Final message confirms VIP list.

Data logged:
- `Contacts` upsert
- `Leads` row appended (`intent = buyer`)

---

## Private Lending Flow

When user clicks **Private Lending**, they see the intro message and then:

1. First name  
2. Phone number  
3. Email address  

After email, they receive:
- A button-style download link (HTML) for the presentation
- A fallback view link if the UI strips HTML
- Returned to the main menu

Data logged:
- `Contacts` upsert
- `Leads` row appended (`intent = private_lending`)

---

## Tech Overview

### Cloudflare Worker
- Endpoint: `POST /chat`
- Responds with JSON:
  - `message`
  - `quick_replies`
  - `session_id`

### Session State
Stored in Cloudflare KV (binding: `SESSIONS`)
- Key: `sess:<session_id>`
- TTL: 24 hours

### Google Sheets
Apps Script web app receives:
```json
{
  "secret": "YOUR_SECRET",
  "action": "upsert_contact | append_lead | append_event",
  "payload": { ... }
}
```

---

## Required Environment Variables (Cloudflare Worker)

Set these in **Worker → Settings → Variables**:

### Secrets
- `OPENAI_API_KEY` *(optional unless you later add true AI responses)*
- `SHEETS_SECRET`

### Variables
- `SHEETS_WEBAPP_URL`

### KV Namespace Binding
- Binding name: `SESSIONS`

---

## Google Sheet Tabs / Headers

### Contacts tab headers
```
contact_id, created_at, updated_at, name, phone, email, preferred_channel,
location_city, location_state, location_country, persona, stage, engagement_score,
tags, last_intent, last_seen_at
```

### Leads tab headers
```
lead_id, created_at, contact_id, intent, name, phone, email, address, city, state, zip,
reason, estimated_value, condition, sell_timeframe, buy_timeframe, price_range,
property_type, zip_codes, funding_type, bank_status, down_payment, monthly_payment_cap,
notes, source, page
```

### Events tab headers
```
event_id, timestamp, contact_id, event_name, text, source
```

---

## Validation & Checks Performed

We confirmed the system worked end-to-end using:

### 1) Worker “2-second test”
POST empty message:
- Expected: menu + quick replies

### 2) Worker “10-second test”
Ran full flows:
- Seller flow completed and wrote lead row
- Buyer flow completed and wrote lead row
- Private lending completed and wrote lead row

### 3) Sheets logging verification
Confirmed rows appear in:
- Contacts
- Leads
- Events

### 4) Common failure modes handled
- CORS preflight OPTIONS works
- Invalid ZIP rejected
- Invalid phone rejected
- Sheets failures do not crash the chat (safeSheets)

---

## Files

- `worker.js` — Cloudflare Worker backend (all flows)
- `Chat bot (cloudflare).txt` — setup / notes from build

---

## Deploy

1. Paste `worker.js` into your Worker
2. Add environment variables + KV binding
3. Deploy
4. Test:
   - `/chat` returns menu
   - Complete a flow and confirm Sheets rows update

---

## License
Private / Internal use (you can add MIT later if you want)
